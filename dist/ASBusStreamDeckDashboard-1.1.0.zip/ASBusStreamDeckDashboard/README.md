# Shopware Stream Deck Companion

Free, open-source Shopware 6 plugin (composer name `asbs/shopware-streamdeck`) that
exposes aggregated dashboard/metric endpoints for the paid Stream Deck plugin
[`de.asbs.shopware`](../streamdeck-plugin/).

## Install (no build step required)

The compiled administration assets are committed under
`src/Resources/public/administration/`, so the plugin is **ready to use right after
installation** — there is no need to run `bin/build-administration.sh` on the target
shop. After install + activate, everything is configured in the admin UI.

> The committed assets were built against the Shopware **6.7** admin toolchain and the
> admin UI was verified on 6.7. The plugin targets **Shopware 6.7 only** (composer
> constraint `^6.7`); 6.6 is not supported.

```bash
bin/console plugin:refresh
bin/console plugin:install --activate AsbsShopwareStreamDeck
bin/console cache:clear
```

Then open **Settings → Extensions → Shopware Stream Deck Companion → Configuration**:

- **API access** card — generate / list / revoke API keys (the secret is shown once).
- **Order filter** card — pick which order/payment states feed the metrics.

A CLI fallback exists but is not required: `bin/console asbs:streamdeck:key:create`.

## Authentication model

- **Companion endpoints** (`ping`, `dashboard`, `metrics/*`) are authenticated **only**
  by the `X-Asbs-Streamdeck-Key` header (the shop-bound shared secret). They are marked
  `auth_required => false` so Shopware's admin OAuth does not block the Stream Deck
  plugin, which only holds the companion key.
- **Key management** (`/keys` CRUD) requires a logged-in **admin user** (not just any API
  token) — an integration token must not be able to mint or revoke keys.

## Endpoints

Authenticated via `X-Asbs-Streamdeck-Key`:

- `GET .../ping` — plugin version + shop id (capability detection).
- `GET .../metrics/latest-order`
- `GET .../metrics/top-order-today`
- `GET .../metrics/revenue-today`
- `GET .../metrics/aov-today`
- `GET .../metrics/revenue-by-day` (`?days=7…60`)
- `GET .../metrics/revenue-by-hour`
- `GET .../metrics/shop-status`
- `GET .../dashboard` — aggregate DTO; currently ships placeholder zeros (not consumed by
  the Stream Deck plugin, which uses the individual `metrics/*` endpoints).

All paths are prefixed with `/api/_action/asbs-streamdeck`.

## Develop

```bash
composer install
vendor/bin/phpunit
vendor/bin/phpstan analyse
vendor/bin/php-cs-fixer fix --dry-run --diff
```

`composer install` will pull `shopware/core` (large). For a CI-equivalent matrix run
locally:

```bash
composer require --no-update "shopware/core:^6.7"
composer update --no-interaction
```

### Rebuilding the administration assets

The committed JS in `src/Resources/public/administration/` only needs to be regenerated
when the admin sources under `src/Resources/app/administration/` change. Build them
against a real Shopware admin toolchain — the simplest reproducible way is
[`shopware-cli`](https://github.com/shopware/shopware-cli):

```bash
shopware-cli extension build .
```

Commit the resulting `src/Resources/public/administration/` (`.vite/entrypoints.json`,
`.vite/manifest.json`, `assets/*`). The output filename carries a content hash, so a
changed source produces a new hash; `git add -A` picks up the rename.

## License

MIT — see [`LICENSE`](LICENSE).
